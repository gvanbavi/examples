package cern.lhc.betabeating.constants;

public class madx_const {
	
	public String[] madxvariables(){
		String[] var=new String[]{"name","s","betx","alfx","bety","alfy","mux","muy","dx","dy"
				,"dpx","dpy","r11","r12","r22","r21","x","y","wx","wy","phix","phiy",
				"k1l","k2l","k3l","k4l","dmux","dmuy","dbx","dby"};
		
		return var;
		
	}

}
