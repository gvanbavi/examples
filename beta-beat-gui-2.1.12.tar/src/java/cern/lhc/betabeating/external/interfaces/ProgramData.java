package cern.lhc.betabeating.external.interfaces;

public interface ProgramData {
    public String getArguments();
}