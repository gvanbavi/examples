package cern.lhc.betabeating.external.interfaces;


public interface Program {
}