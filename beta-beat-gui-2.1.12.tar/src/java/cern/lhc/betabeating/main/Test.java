package cern.lhc.betabeating.main;

public class Test {

    public static boolean doOnlyTestingAndDontLoadGui()
    {
        return false;
    }
}
